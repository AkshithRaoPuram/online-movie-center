package com.screens.babilo.service;

import com.screens.babilo.dataentity.Ticket;

public interface MovieBookingService {

    public void addMovieBooking(Ticket ticket);
}
