package com.screens.babilo.service;

import com.screens.babilo.dataentity.Ticket;

public interface TicketService {

    void addTicket(Ticket ticket);

}
