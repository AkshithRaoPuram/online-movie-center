package com.screens.babilo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabiloApplicationTests {

	@Test
	void contextLoads() {
	}

}
